def reverse(string):
    return string[::-1]
